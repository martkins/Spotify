import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
//import { LoginFacePage } from './login-face';

@NgModule({
  declarations: [
    //LoginFacePage,
  ],
  imports: [
    //IonicPageModule.forChild(LoginFacePage),
  ],
})
export class LoginFacePageModule {}
