import {HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';
import { Injectable } from '@angular/core';
import {InAppBrowser} from "@ionic-native/in-app-browser";
import {HTTP} from "@ionic-native/http";


/*
  Generated class for the SpotifyProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class SpotifyProvider {

  client_id = 'd0612aeb3d0741cb9939c51b25c75394'
  client_secret = '184bdc24e90a48b5984fbb79d1a00211'
  response_type = 'token'
  redirect_uri = 'http://localhost:8100/'
  state = 123
  scope = 'user-modify-playback-state'
  refreshToken = 'AQBeFDI0f8bnvYDnwsdae8idizvEPVlk47H9ON4jqbLjIjuJfBvD6bVXR-WEtKbr_uOY5Ip_NWlC_fzGQZqh1bKd2vzWQ4fGQMNO9db2CfOQENZ72huOIVB8B5hegkxFffI'
  urlRefreshToken = 'https://accounts.spotify.com/api/token'
  resp:any
  body = {
    'grant_type':'refresh_token',
    'client_id':this.client_id,
    'client_secret':this.client_secret,
    'refresh_token':this.refreshToken,
    'scope':this.scope
  }

  // code = 'AQA4Hj6AK5n5Kx9I9PQmd960Sx_eZuV5gL7ehoZgadWpK7swVd-uS-wRQHVzavPSa2yzK86nYNa71EvjA2vogN5QzvCpww0f7m5Fvfw7_fVLhemoV8Qh2TiBbHbqV2SZ60hsJ1gkte4TOcPKN3ig8DW4yxC34RofQIgbvLrXsH4aBIKSq0txDkD-fnw'
  // Per prendere il refreshToken, fare una GET per avere il code, poi fare una POST per avere il refreshToken


  private baseUrl:string = "https://api.spotify.com/v1"
  private searchUrl:string = this.baseUrl+'/search?q='
  private albumsUrl:string = this.baseUrl+'/artists/'
  private albumUrl:string = this.baseUrl+'/albums/'
  public authToken:string
  //private authToken:string =  'Bearer BQDNK0aAox0UVPijXmzUxJ2Bli2GsG3BFdCWZurDCAhRLOxz5KKTO92koLjWFPrrpPmnvH9bWGEdtRvixA5fclphOzZt4wQXhRS6mt2c_hbXenYxhsMzM79jFw5aB-UphhSdM3Ww3Mgit06SFKgo44MvguV6EkgMlrBaxeHKXEsP0q5XhUoPQzcD1txwCw8kT0-i38YyeyDNLprRyjMCK8Ibi406d5tS1O5TDjHBCOuAwHZb_vOoBCztYC4'
  //private requestHeader = new HttpHeaders().set('Content-Type','application/json').append('Authorization',this.authToken)

  public requestHeader:any;



  constructor(public http: HttpClient, public iab:InAppBrowser, public HTTP:HTTP) {
    console.log('Hello SpotifyProvider Provider');
    if (window.location.href.toString().includes('token')) {
      let begin = window.location.href.toString().indexOf('=')
      let end = window.location.href.toString().indexOf('token_type')
      this.authToken = 'Bearer '+window.location.href.toString().slice(begin + 1, end - 1)
      this.requestHeader = new HttpHeaders().set('Content-Type','application/json').append('Authorization',this.authToken)
      console.log('request',this.requestHeader)
      console.log('token',this.authToken)
      console.log('https://accounts.spotify.com/authorize?client_id=' + this.client_id + '&redirect_uri=' + this.redirect_uri + '&response_type=' + this.response_type + '&state=' + this.state, '_system')


    }
    }


  searchArtists(name:string){
    console.log('Token:',this.authToken)
    return this.http.get(this.searchUrl+name+'&type=artist',{
      headers:this.requestHeader
    })
  }
  searchAlbums(id:string){
    return this.http.get(this.albumsUrl+id+'/albums',{
      headers:this.requestHeader
    })
  }
  searchAlbum(id:string){
    return this.http.get(this.albumUrl+id,{
      headers:this.requestHeader
    })
  }

  loginComputer(){
    window.open('https://accounts.spotify.com/authorize?client_id=' + this.client_id + '&redirect_uri=' + this.redirect_uri + '&response_type=' + this.response_type + '&state=' + this.state + '&scope='+this.scope, '_system')
  }

  refresh() {
    let headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    return this.HTTP.post(this.urlRefreshToken, this.body, headers)
  }



}
