import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { SpotifyProvider} from "../../providers/spotify/spotify";
import {ArtistAlbumsPage} from "../artist-albums/artist-albums";
import {LoginFacePage} from "../login-face/login-face";
import {NativeStorage} from "@ionic-native/native-storage";
import {Storage} from "@ionic/storage";

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  private resp:any;
  private items:any;
  code:any;
  constructor(public navCtrl: NavController, private spotifyProvider:SpotifyProvider, public storage:Storage) {


  }


  search(event:any){
    let value = event.target.value;
    console.log(value);
    this.spotifyProvider.searchArtists(value).subscribe(
      data=>{
        //this.items = data.artists.items;
        this.resp = data;
        this.items = this.resp.artists.items;
        console.log(this.items);

      },
      error=>{
        console.log(error);
      }
    )
  }

  searchAlbums(id:string,name:string){
    this.navCtrl.push(ArtistAlbumsPage,{
      id:id,
      name:name
    })
  }

  loginSpotify(){
    this.navCtrl.push(LoginFacePage)
  }
}
