import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {Facebook} from "@ionic-native/facebook";
import {HomePage} from "../home/home";
import {NativeStorage} from "@ionic-native/native-storage";
import {SpotifyProvider} from "../../providers/spotify/spotify";

/**
 * Generated class for the LoginFacePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login-face',
  templateUrl: 'login-face.html',
})
export class LoginFacePage {

  FB_APP_ID = 964975850294068

  constructor(public navCtrl: NavController, public navParams: NavParams, public facebook:Facebook, public nativeStorage:NativeStorage, private spotifyProvider:SpotifyProvider) {
  }



  loginFb(){
    let permissions = new Array<string>();
    let nav = this.navCtrl;

    permissions=["public_profile"];

    this.facebook.login(permissions)
      .then((response)=>{
        let userId = response.authResponse.userID;
        let params = new Array<string>();

        this.facebook.api("/me?fields=name,gender",params)
          .then((user)=>{
            user.picture = "https://graph.facebook.com/" + userId + "/picture?type=large";
            this.nativeStorage.setItem('user',
              {
                name:user.name,
                gender:user.gender,
                picture:user.picture
              })
              .then(()=>{
                nav.push(HomePage)
              },(error)=>{
                console.log(error);
              })
          })
      },(error)=>{
        console.log(error);
      })

  }
  home(){
    this.spotifyProvider.login()
  }
}
