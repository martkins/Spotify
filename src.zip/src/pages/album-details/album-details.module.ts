import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
//import { AlbumDetailsPage } from './album-details';

@NgModule({
  declarations: [
    //AlbumDetailsPage,
  ],
  imports: [
    //IonicPageModule.forChild(AlbumDetailsPage),
  ],
})
export class AlbumDetailsPageModule {}
