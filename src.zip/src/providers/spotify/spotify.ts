import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {InAppBrowser} from "@ionic-native/in-app-browser";
import {Storage} from "@ionic/storage";
import {Platform} from "ionic-angular";

/*
  Generated class for the SpotifyProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class SpotifyProvider {

  client_id = 'd0612aeb3d0741cb9939c51b25c75394'
  response_type = 'token'
  redirect_uri = 'http://localhost:8100/'
  state = 123
  scope = 'streaming'


  private baseUrl:string = "https://api.spotify.com/v1"
  private searchUrl:string = this.baseUrl+'/search?q='
  private albumsUrl:string = this.baseUrl+'/artists/'
  private albumUrl:string = this.baseUrl+'/albums/'
  private authToken:string
  //private authToken:string =  'Bearer BQDNK0aAox0UVPijXmzUxJ2Bli2GsG3BFdCWZurDCAhRLOxz5KKTO92koLjWFPrrpPmnvH9bWGEdtRvixA5fclphOzZt4wQXhRS6mt2c_hbXenYxhsMzM79jFw5aB-UphhSdM3Ww3Mgit06SFKgo44MvguV6EkgMlrBaxeHKXEsP0q5XhUoPQzcD1txwCw8kT0-i38YyeyDNLprRyjMCK8Ibi406d5tS1O5TDjHBCOuAwHZb_vOoBCztYC4'
  //private requestHeader = new HttpHeaders().set('Content-Type','application/json').append('Authorization',this.authToken)

  private requestHeader:any;



  constructor(public http: HttpClient, public iab:InAppBrowser,public storage:Storage,private platform:Platform) {
    console.log('Hello SpotifyProvider Provider');
    if (window.location.href.toString().includes('token')) {
      let begin = window.location.href.toString().indexOf('=')
      let end = window.location.href.toString().indexOf('token_type')
      this.authToken = 'Bearer '+window.location.href.toString().slice(begin + 1, end - 1)
      this.requestHeader = new HttpHeaders().set('Content-Type','application/json').append('Authorization',this.authToken)
      console.log('request',this.requestHeader)
      console.log('token',this.authToken)
    }


  }


  searchArtists(name:string){
    console.log(this.authToken)
    return this.http.get(this.searchUrl+name+'&type=artist',{
      headers:this.requestHeader
    })
  }
  searchAlbums(id:string){
    return this.http.get(this.albumsUrl+id+'/albums',{
      headers:this.requestHeader
    })
  }
  searchAlbum(id:string){
    return this.http.get(this.albumUrl+id,{
      headers:this.requestHeader
    })
  }
  login(){

    if (this.platform.is('ios')){
      window.open('https://accounts.spotify.com/authorize?client_id='+this.client_id+'&redirect_uri=provaSpotify://&response_type='+this.response_type+'&state='+this.state,'_system')

    }else {
      window.open('https://accounts.spotify.com/authorize?client_id=' + this.client_id + '&redirect_uri=' + this.redirect_uri + '&response_type=' + this.response_type + '&state=' + this.state, '_system')

    }
  }



}
